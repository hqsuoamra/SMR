import math
import sys
from controller import Robot, Keyboard, Camera, Lidar, DistanceSensor

WHEEL_RADIUS = 0.123
LX = 0.2045
LY = 0.2225
SPEED_INCREMENT = 0.01
MAX_SPEED = 0.5

robot = Robot()

time_step = int(robot.getBasicTimeStep())

motor_fl = robot.getDevice("front_left_wheel_joint")
motor_fr = robot.getDevice("front_right_wheel_joint")
motor_bl = robot.getDevice("back_left_wheel_joint")
motor_br = robot.getDevice("back_right_wheel_joint")

motor_fl.setPosition(float('inf'))
motor_fr.setPosition(float('inf'))
motor_bl.setPosition(float('inf'))
motor_br.setPosition(float('inf'))

motor_fl.setVelocity(0)
motor_fr.setVelocity(0)
motor_bl.setVelocity(0)
motor_br.setVelocity(0)

target_speed = [0.0, 0.0, 0.0]
speed_id = 0
sign = 0
motor_speed = [0.0, 0.0, 0.0, 0.0]

keyboard = robot.getKeyboard()
keyboard.enable(time_step)

camera = robot.getDevice("camera")
camera.enable(time_step)

lidar = robot.getDevice("lidar")
lidar.enable(time_step)

ultrasonic = robot.getDevice("ultrasonic")
ultrasonic.enable(time_step)

print("To move the Summit-XL Steel with your keyboard, click first inside the simulation window and press:\n \
  vx   : ↑/↓               \n \
  vy   : ←/→               \n \
  ω    : Page Up/Page Down \n \
  Reset: Space bar         \n")

while robot.step(time_step) != -1:
    key = keyboard.getKey()
    is_key_valid = True
    if key == Keyboard.UP:
        speed_id = 0
        sign = 1
    elif key == Keyboard.DOWN:
        speed_id = 0
        sign = -1
    elif key == Keyboard.LEFT:
        speed_id = 1
        sign = 1
    elif key == Keyboard.RIGHT:
        speed_id = 1
        sign = -1
    elif key == Keyboard.PAGEUP:
        speed_id = 2
        sign = 1
    elif key == Keyboard.PAGEDOWN:
        speed_id = 2
        sign = -1
    elif key == ord(' '):
        sign = 0
    else:
        is_key_valid = False
        sign = 0

    if is_key_valid:
        if sign > 0:
            target_speed[speed_id] += SPEED_INCREMENT
            if target_speed[speed_id] > MAX_SPEED:
                target_speed[speed_id] = MAX_SPEED
        elif sign < 0:
            target_speed[speed_id] -= SPEED_INCREMENT
            if target_speed[speed_id] < -MAX_SPEED:
                target_speed[speed_id] = -MAX_SPEED
        else:
            for i in range(3):
                target_speed[i] = 0

        # Sensor data
        camera_data = camera.getImage()
        lidar_data = lidar.getRangeImage()
        ultrasonic_data = ultrasonic.getValue()

        # Obstacle avoidance logic (simplified)
        if ultrasonic_data < 0.2 or any(d < 0.2 for d in lidar_data):
            # If an obstacle is detected in front of the robot, stop or change direction.
            for i in range(3):
                target_speed[i] = 0.0

        motor_speed[0] = 1 / WHEEL_RADIUS * (target_speed[0] - target_speed[1] - (LX + LY) * target_speed[2])
        motor_speed[1] = 1 / WHEEL_RADIUS * (target_speed[0] + target_speed[1] + (LX + LY) * target_speed[2])
        motor_speed[2] = 1 / WHEEL_RADIUS * (target_speed[0] + target_speed[1] - (LX + LY) * target_speed[2])
        motor_speed[3] = 1 / WHEEL_RADIUS * (target_speed[0] - target_speed[1] + (LX + LY) * target_speed[2])

        motor_fl.setVelocity(motor_speed[0])
        motor_fr.setVelocity(motor_speed[1])
        motor_bl.setVelocity(motor_speed[2])
        motor_br.setVelocity(motor_speed[3])

sys.exit(0)
